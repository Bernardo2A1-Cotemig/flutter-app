package com.example.atvrevisao

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
