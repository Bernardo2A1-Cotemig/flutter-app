import 'package:flutter/material.dart';

class TelaLogin extends StatefulWidget {
  const TelaLogin({super.key});

  @override
  State<TelaLogin> createState() => _TelaLoginState();
}

class _TelaLoginState extends State<TelaLogin> {
  final _emailController = TextEditingController();
  final _senhaController = TextEditingController();
  String _erro = '';

  void _entrar() {
    final email = _emailController.text.trim();
    final senha = _senhaController.text;

    setState(() {
      if (email.isEmpty) {
        _erro = 'Digite seu email';
      } else if (!email.contains('@')) {
        _erro = 'Digite um email válido';
      } else if (senha.isEmpty) {
        _erro = 'Digite sua senha';
      } else {
        _erro = '';
        Navigator.pushReplacementNamed(context, '/home');
      }
    });
  }

  @override
  void dispose() {
    _emailController.dispose();
    _senhaController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.lock, size: 60),
            const SizedBox(height: 10),
            const Text('Login', style: TextStyle(fontSize: 24)),
            const SizedBox(height: 10),
            const Text('Preencha os dados abaixo'),
            const SizedBox(height: 20),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(labelText: 'Email'),
            ),
            TextField(
              controller: _senhaController,
              decoration: const InputDecoration(labelText: 'Senha'),
              obscureText: true,
            ),
            const SizedBox(height: 10),
            Text(_erro, style: const TextStyle(color: Colors.red)),
            const SizedBox(height: 20),
            ElevatedButton(
              onPressed: _entrar,
              child: const Text('Entrar'),
            ),
            TextButton(
              onPressed: () {
                Navigator.pushNamed(context, '/cadastro');
              },
              child: const Text('Criar conta'),
            ),
          ],
        ),
      ),
    );
  }
}