package com.example.atvckima

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
