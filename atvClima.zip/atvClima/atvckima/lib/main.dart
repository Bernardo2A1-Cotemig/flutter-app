import 'package:flutter/material.dart';
import 'pages/tela_clima.dart';
import 'package:device_preview/device_preview.dart';

void main() {
  runApp(
    DevicePreview(
      builder: (context) => MyApp(),
    ),
  );
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      title: 'Clima Agora',
      debugShowCheckedModeBanner: false,
      home: TelaClima(),
    );
  }
}