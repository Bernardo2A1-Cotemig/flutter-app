import 'package:flutter/material.dart';
import '../widgets/area_cidades.dart';
import '../widgets/painel_informacoes.dart';

class TelaClima extends StatelessWidget {
  const TelaClima({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Clima Agora', style: TextStyle(fontFamily: 'serif', fontWeight: FontWeight.bold)),
        backgroundColor: const Color(0xff5c3d99),
        foregroundColor: Colors.white,
      ),
      body: LayoutBuilder(
        builder: (context, constraints) {
          final largura = constraints.maxWidth;
          
          final bool isCelular = largura < 600;
          final bool isTablet = largura >= 600 && largura < 900;
          final bool isDesktop = largura >= 900;

          int colunasGrid = 1;
          String nomeDispositivo = 'Celular';

          if (isTablet) {
            colunasGrid = 2;
            nomeDispositivo = 'Tablet';
          } else if (isDesktop) {
            colunasGrid = 3;
            nomeDispositivo = 'Desktop';
          }

          return SingleChildScrollView(
            padding: const EdgeInsets.all(12.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                AspectRatio(
                  aspectRatio: 16 / 4,
                  child: Container(
                    color: const Color(0xff5c3d99),
                    padding: const EdgeInsets.all(8),
                    alignment: Alignment.center,
                    child: const FittedBox(
                      fit: BoxFit.scaleDown,
                      child: Column(
                        children: [
                          Text(
                            'Clima Agora', 
                            style: TextStyle(fontFamily: 'serif', fontSize: 26, fontWeight: FontWeight.bold, color: Colors.white)
                          ),
                          Text(
                            'Confira as condicoes do tempo em diversas cidades.', 
                            style: TextStyle(fontFamily: 'serif', color: Colors.white70)
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),

                Container(
                  padding: const EdgeInsets.all(6),
                  color: const Color(0xffe0e0e0),
                  child: Text(
                    'Largura atual: ${largura.toStringAsFixed(0)} px | Dispositivo: $nomeDispositivo',
                    textAlign: TextAlign.center,
                    style: const TextStyle(fontFamily: 'monospace', fontWeight: FontWeight.bold),
                  ),
                ),
                const SizedBox(height: 12),

                if (isDesktop) ...[
                  const Text(
                    'Dados climaticos atualizados em tempo real.', 
                    textAlign: TextAlign.center,
                    style: TextStyle(fontFamily: 'serif', fontStyle: FontStyle.italic, color: Colors.teal, fontWeight: FontWeight.bold),
                  ),
                  const SizedBox(height: 12),
                ],

                Wrap(
                  spacing: 6.0,
                  runSpacing: 6.0,
                  alignment: WrapAlignment.center,
                  children: ['Ensolarado', 'Chuvoso', 'Frio', 'Quente', 'Nublado', 'Vento Forte'].map((tag) {
                    return Container(
                      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                      color: const Color(0xff333333),
                      child: Text(tag, style: const TextStyle(fontFamily: 'serif', color: Colors.white, fontSize: 12)),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 12),

                if (isTablet) ...[
                  ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xffffb300),
                      foregroundColor: const Color(0xff333333),
                      shape: const LinearBorder(),
                    ),
                    onPressed: () {},
                    child: const Text('Ver previsao para 7 dias', style: TextStyle(fontFamily: 'serif', fontWeight: FontWeight.bold)),
                  ),
                  const SizedBox(height: 12),
                ],

                if (isDesktop)
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Expanded(
                        flex: 2,
                        child: AreaCidades(colunas: colunasGrid, limitarCidades: isCelular),
                      ),
                      const SizedBox(width: 12),
                      const Expanded(
                        flex: 1,
                        child: PainelInformacoes(),
                      ),
                    ],
                  )
                else ...[
                  AreaCidades(colunas: colunasGrid, limitarCidades: isCelular),
                  const SizedBox(height: 12),
                  const PainelInformacoes(),
                ],
              ],
            ),
          );
        },
      ),
    );
  }
}