import 'package:flutter/material.dart';
import '../models/cidade_clima.dart';
import 'cidade_card.dart';

class AreaCidades extends StatelessWidget {
  final int colunas;
  final bool limitarCidades;

  const AreaCidades({
    super.key,
    required this.colunas,
    required this.limitarCidades,
  });

  @override
  Widget build(BuildContext context) {
    final todasCidades = CidadeClima.obterCidades();
    final cidadesExibidas = limitarCidades ? todasCidades.take(4).toList() : todasCidades;

    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
        crossAxisCount: colunas,
        crossAxisSpacing: 8,
        mainAxisSpacing: 8,
        childAspectRatio: 0.9,
      ),
      itemCount: cidadesExibidas.length,
      itemBuilder: (context, index) {
        return CidadeCard(cidade: cidadesExibidas[index]);
      },
    );
  }
}