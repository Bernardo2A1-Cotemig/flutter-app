import 'package:flutter/material.dart';
import '../models/cidade_clima.dart';

class CidadeCard extends StatelessWidget {
  final CidadeClima cidade;

  const CidadeCard({super.key, required this.cidade});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xfff5f5f5),
        border: Border.all(color: const Color(0xff333333), width: 2),
      ),
      padding: const EdgeInsets.all(12.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(cidade.icone, size: 32, color: const Color(0xff5c3d99)),
          const SizedBox(height: 6),
          Text(
            cidade.nome, 
            style: const TextStyle(fontFamily: 'serif', fontWeight: FontWeight.bold, fontSize: 15)
          ),
          Text(
            '${cidade.temperatura}C', 
            style: const TextStyle(fontFamily: 'monospace', fontSize: 20, fontWeight: FontWeight.bold)
          ),
          Text(
            cidade.condicao, 
            style: const TextStyle(fontFamily: 'serif', fontStyle: FontStyle.italic, color: Colors.black54)
          ),
          const SizedBox(height: 8),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: const Color(0xff5c3d99),
              foregroundColor: Colors.white,
              shape: const LinearBorder(),
            ),
            onPressed: () {},
            child: const Text('Ver detalhes', style: TextStyle(fontFamily: 'serif')),
          ),
        ],
      ),
    );
  }
}