import 'package:flutter/material.dart';

class PainelInformacoes extends StatelessWidget {
  const PainelInformacoes({super.key});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: const Color(0xff333333),
        border: Border.all(color: const Color(0xffffb300), width: 2),
      ),
      padding: const EdgeInsets.all(12.0),
      child: const Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Informacoes Extras', 
            style: TextStyle(fontFamily: 'serif', fontWeight: FontWeight.bold, fontSize: 16, color: Color(0xffffb300))
          ),
          SizedBox(height: 8),
          Text('Umidade: 65%', style: TextStyle(fontFamily: 'monospace', color: Colors.white)),
          Text('Vento: 12 km/h', style: TextStyle(fontFamily: 'monospace', color: Colors.white)),
          Text('Sensacao termica: 30C', style: TextStyle(fontFamily: 'monospace', color: Colors.white)),
          Text('Nascer do sol: 06:10', style: TextStyle(fontFamily: 'monospace', color: Colors.white)),
        ],
      ),
    );
  }
}