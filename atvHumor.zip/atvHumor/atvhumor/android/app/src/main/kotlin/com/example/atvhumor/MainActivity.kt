package com.example.atvhumor

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
