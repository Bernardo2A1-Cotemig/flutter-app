import 'package:flutter/material.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  Color _cor = Colors.grey;
  double _tamanho = 150.0;
  IconData _icone = Icons.sentiment_neutral;
  String _texto = "Escolha um humor";
  double _borda = 10.0;
  double _opacidade = 0.0;
  String _mensagemExtra = "";

  void _atualizarHumor(String humor) {
    setState(() {
      _opacidade = 0.0;

      if (humor == 'Feliz') {
        _cor = Colors.yellow;
        _tamanho = 200.0;
        _icone = Icons.sentiment_very_satisfied;
        _texto = "Hoje estou feliz!";
        _borda = 30.0;
        _mensagemExtra = "Você escolheu o humor Feliz. Que bom ver essa energia positiva!";
      } else if (humor == 'Calmo') {
        _cor = Colors.blue;
        _tamanho = 130.0;
        _icone = Icons.cloud;
        _texto = "Momento de tranquilidade.";
        _borda = 5.0;
        _mensagemExtra = "Você escolheu o humor Calmo. Que bom ver essa energia positiva!";
      } else if (humor == 'Animado') {
        _cor = Colors.orange;
        _tamanho = 250.0;
        _icone = Icons.bolt;
        _texto = "Energia total!";
        _borda = 100.0;
        _mensagemExtra = "Você escolheu o humor Animado. Que bom ver essa energia positiva!";
      }
    });

    Future.delayed(const Duration(milliseconds: 200), () {
      if (mounted) {
        setState(() {
          _opacidade = 1.0;
        });
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Meu App')),
      body: SingleChildScrollView(
        child: Container(
          padding: const EdgeInsets.all(20.0),
          width: double.infinity,
          child: Column(
            children: [
              const Text(
                'Meu App',
                style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
              ),
              const Text('Escolha o seu humor atual e veja a tela mudar.'),
              const SizedBox(height: 30),
              AnimatedContainer(
                duration: const Duration(seconds: 1),
                width: _tamanho,
                height: _tamanho,
                decoration: BoxDecoration(
                  color: _cor,
                  borderRadius: BorderRadius.circular(_borda),
                ),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(_icone, size: 50),
                    Text(_texto, textAlign: TextAlign.center),
                  ],
                ),
              ),
              const SizedBox(height: 30),
              AnimatedOpacity(
                duration: const Duration(seconds: 1),
                opacity: _opacidade,
                child: Text(_mensagemExtra, textAlign: TextAlign.center),
              ),
              const SizedBox(height: 40),
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                children: [
                  ElevatedButton(
                    onPressed: () => _atualizarHumor('Feliz'),
                    child: const Text('Feliz'),
                  ),
                  ElevatedButton(
                    onPressed: () => _atualizarHumor('Calmo'),
                    child: const Text('Calmo'),
                  ),
                  ElevatedButton(
                    onPressed: () => _atualizarHumor('Animado'),
                    child: const Text('Animado'),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}