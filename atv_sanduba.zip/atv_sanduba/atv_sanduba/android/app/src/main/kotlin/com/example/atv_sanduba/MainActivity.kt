package com.example.atv_sanduba

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
