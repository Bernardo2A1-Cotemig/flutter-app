import 'package:flutter/material.dart';

class TelaFavoritos extends StatelessWidget {
  const TelaFavoritos({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Favoritos'),
      ),
      body: ListView(
        children: const [
          ListTile(
            leading: Icon(Icons.sports_esports),
            title: Text('Elden Ring'),
            subtitle: Text('RPG'),
          ),
          ListTile(
            leading: Icon(Icons.sports_esports),
            title: Text('Zelda: Kingdom'),
            subtitle: Text('Aventura'),
          ),
        ],
      ),
    );
  }
}