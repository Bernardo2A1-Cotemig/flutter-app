import 'package:flutter/material.dart';

import '../providers/produto_provider.dart';

class CadastroProdutoPage extends StatefulWidget {
  const CadastroProdutoPage({super.key});

  @override
  State<CadastroProdutoPage> createState() =>
      _CadastroProdutoPageState();
}

class _CadastroProdutoPageState
    extends State<CadastroProdutoPage> {
  final nomeController = TextEditingController();
  final categoriaController = TextEditingController();
  final quantidadeController = TextEditingController();
  final precoController = TextEditingController();

  final ProdutoProvider provider = ProdutoProvider();

  bool loading = false;

  @override
  void dispose() {
    nomeController.dispose();
    categoriaController.dispose();
    quantidadeController.dispose();
    precoController.dispose();
    super.dispose();
  }

  Future<void> cadastrar() async {
    if (loading) return;

    final nome = nomeController.text.trim();
    final categoria = categoriaController.text.trim();

    final quantidade =
        int.tryParse(quantidadeController.text.trim());

    final preco = double.tryParse(
      precoController.text.trim().replaceAll(',', '.'),
    );

    if (nome.isEmpty ||
        categoria.isEmpty ||
        quantidade == null ||
        preco == null) {
      mensagem(
        'Preencha os campos corretamente.',
        erro: true,
      );
      return;
    }

    if (quantidade < 0 || preco < 0) {
      mensagem(
        'Quantidade e preço não podem ser negativos.',
        erro: true,
      );
      return;
    }

    setState(() {
      loading = true;
    });

    try {
      final sucesso = await provider.cadastrarProduto(
        nome: nome,
        categoria: categoria,
        quantidade: quantidade,
        preco: preco,
      );

      if (!mounted) return;

      setState(() {
        loading = false;
      });

      if (!sucesso) {
        mensagem(
          'Não foi possível cadastrar o produto.',
          erro: true,
        );
        return;
      }

      await provider.mostrarProdutosNoTerminal();

      await showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('Produto cadastrado!'),
            content: Text(
              '$nome foi cadastrado com sucesso.',
            ),
            actions: [
              ElevatedButton(
                onPressed: () {
                  Navigator.pop(context);
                },
                child: const Text('OK'),
              ),
            ],
          );
        },
      );

      if (!mounted) return;

      Navigator.pop(context);
    } catch (e, stack) {
      print('ERRO NO CADASTRO DO PRODUTO: $e');
      print(stack);

      if (!mounted) return;

      setState(() {
        loading = false;
      });

      mensagem(
        'Erro ao cadastrar produto.',
        erro: true,
      );
    }
  }

  void mensagem(
    String texto, {
    bool erro = false,
  }) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(texto),
        backgroundColor: erro ? Colors.red : Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Cadastrar Produto'),
      ),
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(
              maxWidth: 550,
            ),
            child: Card(
              elevation: 3,
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  children: [
                    const Icon(
                      Icons.add_box,
                      size: 70,
                      color: Color(0xFF00A896),
                    ),

                    const SizedBox(height: 20),

                    const Text(
                      'NOVO PRODUTO',
                      style: TextStyle(
                        fontSize: 27,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 30),

                    TextField(
                      controller: nomeController,
                      decoration: const InputDecoration(
                        labelText: 'Nome do produto',
                        prefixIcon: Icon(Icons.inventory_2),
                      ),
                    ),

                    const SizedBox(height: 16),

                    TextField(
                      controller: categoriaController,
                      decoration: const InputDecoration(
                        labelText: 'Categoria',
                        prefixIcon: Icon(Icons.category),
                      ),
                    ),

                    const SizedBox(height: 16),

                    TextField(
                      controller: quantidadeController,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Quantidade',
                        prefixIcon: Icon(Icons.numbers),
                      ),
                    ),

                    const SizedBox(height: 16),

                    TextField(
                      controller: precoController,
                      keyboardType:
                          const TextInputType.numberWithOptions(
                        decimal: true,
                      ),
                      decoration: const InputDecoration(
                        labelText: 'Preço',
                        prefixIcon: Icon(Icons.attach_money),
                      ),
                    ),

                    const SizedBox(height: 25),

                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: loading ? null : cadastrar,
                        child: loading
                            ? const SizedBox(
                                height: 24,
                                width: 24,
                                child: CircularProgressIndicator(),
                              )
                            : const Text(
                                'CADASTRAR PRODUTO',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}