import 'package:flutter/material.dart';

import '../models/produto.dart';
import '../providers/produto_provider.dart';

class EstoquePage extends StatefulWidget {
  const EstoquePage({super.key});

  @override
  State<EstoquePage> createState() => _EstoquePageState();
}

class _EstoquePageState extends State<EstoquePage> {
  final ProdutoProvider provider = ProdutoProvider();

  List<Produto> produtos = [];
  bool loading = true;

  @override
  void initState() {
    super.initState();
    carregarProdutos();
  }

  Future<void> carregarProdutos() async {
    try {
      setState(() {
        loading = true;
      });

      final resultado = await provider.listarProdutos();

      if (!mounted) return;

      setState(() {
        produtos = resultado;
        loading = false;
      });

      await provider.mostrarProdutosNoTerminal();
    } catch (e, stack) {
      print('ERRO AO CARREGAR ESTOQUE: $e');
      print(stack);

      if (!mounted) return;

      setState(() {
        loading = false;
      });

      mensagem(
        'Erro ao carregar o estoque.',
        erro: true,
      );
    }
  }

  Future<void> alterarQuantidade(
    Produto produto,
    int novaQuantidade,
  ) async {
    if (novaQuantidade < 0) return;

    await provider.alterarQuantidade(
      produto.id!,
      novaQuantidade,
    );

    await carregarProdutos();
  }

  Future<void> excluirProduto(Produto produto) async {
    final confirmar = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Excluir produto?'),
          content: Text(
            'Deseja realmente excluir "${produto.nome}"?',
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context, false);
              },
              child: const Text('CANCELAR'),
            ),
            ElevatedButton(
              onPressed: () {
                Navigator.pop(context, true);
              },
              child: const Text('EXCLUIR'),
            ),
          ],
        );
      },
    );

    if (confirmar != true) return;

    await provider.excluirProduto(produto.id!);

    await carregarProdutos();

    if (!mounted) return;

    mensagem('Produto excluído com sucesso!');
  }

  void mensagem(
    String texto, {
    bool erro = false,
  }) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(texto),
        backgroundColor: erro ? Colors.red : Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Estoque'),
        actions: [
          IconButton(
            tooltip: 'Atualizar',
            onPressed: carregarProdutos,
            icon: const Icon(Icons.refresh),
          ),
        ],
      ),
      body: loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : produtos.isEmpty
              ? const Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        Icons.inventory_2_outlined,
                        size: 80,
                        color: Colors.grey,
                      ),
                      SizedBox(height: 15),
                      Text(
                        'Nenhum produto cadastrado.',
                        style: TextStyle(
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                )
              : RefreshIndicator(
                  onRefresh: carregarProdutos,
                  child: ListView.builder(
                    padding: const EdgeInsets.all(20),
                    itemCount: produtos.length,
                    itemBuilder: (context, index) {
                      final produto = produtos[index];

                      final estoqueBaixo =
                          produto.quantidade <= 3;

                      return Card(
                        margin:
                            const EdgeInsets.only(bottom: 15),
                        child: Padding(
                          padding: const EdgeInsets.all(18),
                          child: Column(
                            crossAxisAlignment:
                                CrossAxisAlignment.start,
                            children: [
                              Row(
                                children: [
                                  Expanded(
                                    child: Text(
                                      produto.nome,
                                      style: const TextStyle(
                                        fontSize: 21,
                                        fontWeight:
                                            FontWeight.bold,
                                      ),
                                    ),
                                  ),
                                  IconButton(
                                    tooltip: 'Excluir',
                                    onPressed: () =>
                                        excluirProduto(produto),
                                    icon: const Icon(
                                      Icons.delete,
                                      color: Colors.red,
                                    ),
                                  ),
                                ],
                              ),

                              const SizedBox(height: 5),

                              Text(
                                'Categoria: ${produto.categoria}',
                                style: const TextStyle(
                                  color: Colors.grey,
                                ),
                              ),

                              const SizedBox(height: 15),

                              Row(
                                children: [
                                  const Text(
                                    'Quantidade: ',
                                    style: TextStyle(
                                      fontWeight:
                                          FontWeight.bold,
                                    ),
                                  ),

                                  IconButton(
                                    onPressed:
                                        produto.quantidade > 0
                                            ? () =>
                                                alterarQuantidade(
                                                  produto,
                                                  produto.quantidade -
                                                      1,
                                                )
                                            : null,
                                    icon: const Icon(
                                      Icons.remove_circle,
                                    ),
                                  ),

                                  Text(
                                    '${produto.quantidade}',
                                    style: const TextStyle(
                                      fontSize: 20,
                                      fontWeight:
                                          FontWeight.bold,
                                    ),
                                  ),

                                  IconButton(
                                    onPressed: () =>
                                        alterarQuantidade(
                                          produto,
                                          produto.quantidade + 1,
                                        ),
                                    icon: const Icon(
                                      Icons.add_circle,
                                    ),
                                  ),
                                ],
                              ),

                              Text(
                                'Preço: R\$ ${produto.preco.toStringAsFixed(2)}',
                                style: const TextStyle(
                                  fontSize: 16,
                                ),
                              ),

                              if (estoqueBaixo) ...[
                                const SizedBox(height: 12),
                                Container(
                                  padding:
                                      const EdgeInsets.symmetric(
                                    horizontal: 12,
                                    vertical: 8,
                                  ),
                                  decoration: BoxDecoration(
                                    color: Colors.orange.shade100,
                                    borderRadius:
                                        BorderRadius.circular(8),
                                  ),
                                  child: const Row(
                                    mainAxisSize:
                                        MainAxisSize.min,
                                    children: [
                                      Icon(
                                        Icons.warning,
                                        color: Colors.orange,
                                      ),
                                      SizedBox(width: 8),
                                      Text(
                                        'ESTOQUE BAIXO',
                                        style: TextStyle(
                                          color:
                                              Colors.orange,
                                          fontWeight:
                                              FontWeight.bold,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ],
                            ],
                          ),
                        ),
                      );
                    },
                  ),
                ),
    );
  }
}