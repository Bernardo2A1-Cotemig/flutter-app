import 'package:flutter/material.dart';

import '../models/usuario.dart';
import '../providers/usuario_provider.dart';
import 'cadastro_page.dart';
import 'home_page.dart';

class LoginPage extends StatefulWidget {
  const LoginPage({super.key});

  @override
  State<LoginPage> createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  final emailController = TextEditingController();
  final senhaController = TextEditingController();

  final UsuarioProvider provider = UsuarioProvider();

  bool loading = false;
  bool esconderSenha = true;

  @override
  void dispose() {
    emailController.dispose();
    senhaController.dispose();
    super.dispose();
  }

  Future<void> entrar() async {
    if (loading) return;

    final email = emailController.text.trim();
    final senha = senhaController.text;

    if (email.isEmpty || senha.isEmpty) {
      mensagem(
        'Preencha o e-mail e a senha.',
        erro: true,
      );
      return;
    }

    setState(() {
      loading = true;
    });

    print('========================================');
    print('TENTANDO FAZER LOGIN');
    print('EMAIL: $email');

    try {
      final Usuario? usuario = await provider.login(
        email,
        senha,
      );

      if (!mounted) return;

      setState(() {
        loading = false;
      });

      if (usuario == null) {
        print('LOGIN NEGADO');

        mensagem(
          'E-mail ou senha incorretos.',
          erro: true,
        );

        return;
      }

      print('LOGIN REALIZADO COM SUCESSO');
      print('USUARIO: ${usuario.nome}');
      print('========================================');

      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => HomePage(usuario: usuario),
        ),
      );
    } catch (e, stack) {
      print('========================================');
      print('ERRO NO LOGIN: $e');
      print(stack);
      print('========================================');

      if (!mounted) return;

      setState(() {
        loading = false;
      });

      mensagem(
        'Erro ao acessar o banco de dados.\nVeja o terminal.',
        erro: true,
      );
    }
  }

  void mensagem(
    String texto, {
    bool erro = false,
  }) {
    ScaffoldMessenger.of(context).hideCurrentSnackBar();

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(texto),
        backgroundColor: erro ? Colors.red : Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(24),
          child: ConstrainedBox(
            constraints: const BoxConstraints(
              maxWidth: 430,
            ),
            child: Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(32),
                child: Column(
                  children: [
                    const Icon(
                      Icons.inventory_2,
                      size: 70,
                      color: Color(0xFF6C4AB6),
                    ),

                    const SizedBox(height: 16),

                    const Text(
                      'ÁREA RESTRITA',
                      style: TextStyle(
                        fontSize: 28,
                        fontWeight: FontWeight.bold,
                      ),
                    ),

                    const SizedBox(height: 8),

                    const Text(
                      'Controle de Estoque',
                      style: TextStyle(
                        color: Colors.grey,
                        fontSize: 16,
                      ),
                    ),

                    const SizedBox(height: 32),

                    TextField(
                      controller: emailController,
                      keyboardType: TextInputType.emailAddress,
                      decoration: const InputDecoration(
                        labelText: 'E-mail',
                        prefixIcon: Icon(Icons.email),
                      ),
                    ),

                    const SizedBox(height: 16),

                    TextField(
                      controller: senhaController,
                      obscureText: esconderSenha,
                      decoration: InputDecoration(
                        labelText: 'Senha',
                        prefixIcon: const Icon(Icons.lock),
                        suffixIcon: IconButton(
                          icon: Icon(
                            esconderSenha
                                ? Icons.visibility
                                : Icons.visibility_off,
                          ),
                          onPressed: () {
                            setState(() {
                              esconderSenha = !esconderSenha;
                            });
                          },
                        ),
                      ),
                      onSubmitted: (_) => entrar(),
                    ),

                    const SizedBox(height: 24),

                    SizedBox(
                      width: double.infinity,
                      height: 50,
                      child: ElevatedButton(
                        onPressed: loading ? null : entrar,
                        child: loading
                            ? const SizedBox(
                                height: 24,
                                width: 24,
                                child: CircularProgressIndicator(),
                              )
                            : const Text(
                                'ENTRAR',
                                style: TextStyle(
                                  fontWeight: FontWeight.bold,
                                ),
                              ),
                      ),
                    ),

                    const SizedBox(height: 12),

                    TextButton(
                      onPressed: loading
                          ? null
                          : () {
                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (_) =>
                                      const CadastroPage(),
                                ),
                              );
                            },
                      child: const Text(
                        'CRIAR CONTA',
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}