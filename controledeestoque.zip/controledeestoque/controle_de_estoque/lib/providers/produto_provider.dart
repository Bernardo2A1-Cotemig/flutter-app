import '../models/produto.dart';
import '../services/produto_service.dart';

class ProdutoProvider {
  final ProdutoService service = ProdutoService.instance;

  Future<bool> cadastrarProduto({
    required String nome,
    required String categoria,
    required int quantidade,
    required double preco,
  }) async {
    final id = await service.inserirProduto(
      nome: nome,
      categoria: categoria,
      quantidade: quantidade,
      preco: preco,
    );

    return id != -1;
  }

  Future<List<Produto>> listarProdutos() async {
    final dados = await service.listarProdutos();

    return dados
        .map((produto) => Produto.fromMap(produto))
        .toList();
  }

  Future<void> alterarQuantidade(
    int id,
    int quantidade,
  ) async {
    await service.atualizarQuantidade(
      id,
      quantidade,
    );
  }

  Future<void> excluirProduto(int id) async {
    await service.excluirProduto(id);
  }

  Future<void> mostrarProdutosNoTerminal() async {
    await service.mostrarProdutosNoTerminal();
  }
}