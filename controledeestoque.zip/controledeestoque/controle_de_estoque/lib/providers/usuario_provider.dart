import '../models/usuario.dart';
import '../services/usuario_service.dart';

class UsuarioProvider {
  final UsuarioService service = UsuarioService.instance;

  Future<bool> cadastrarUsuario({
    required String nome,
    required String email,
    required String senha,
  }) async {
    final existe = await service.emailExiste(email);

    if (existe) {
      return false;
    }

    final id = await service.inserirUsuario(
      nome: nome,
      email: email,
      senha: senha,
    );

    return id != -1;
  }

  Future<Usuario?> login(
    String email,
    String senha,
  ) async {
    final resultado = await service.buscarLogin(
      email,
      senha,
    );

    if (resultado == null) {
      return null;
    }

    return Usuario.fromMap(resultado);
  }
}