import 'package:sqflite/sqflite.dart';

import 'usuario_service.dart';

class ProdutoService {
  ProdutoService._();

  static final ProdutoService instance = ProdutoService._();

  Future<Database> get banco async {
    return await UsuarioService.instance.banco;
  }

  Future<int> inserirProduto({
    required String nome,
    required String categoria,
    required int quantidade,
    required double preco,
  }) async {
    try {
      final db = await banco;

      print('INSERT PRODUTO: $nome');

      final id = await db.insert(
        'produtos',
        {
          'nome': nome,
          'categoria': categoria,
          'quantidade': quantidade,
          'preco': preco,
        },
      );

      print('PRODUTO INSERIDO COM ID: $id');

      return id;
    } catch (e, stack) {
      print('ERRO AO INSERIR PRODUTO: $e');
      print(stack);
      return -1;
    }
  }

  Future<List<Map<String, dynamic>>> listarProdutos() async {
    try {
      final db = await banco;

      print('SELECT ESTOQUE');

      final produtos = await db.query(
        'produtos',
        orderBy: 'nome ASC',
      );

      print('PRODUTOS ENCONTRADOS: ${produtos.length}');

      return produtos;
    } catch (e, stack) {
      print('ERRO AO LISTAR PRODUTOS: $e');
      print(stack);
      rethrow;
    }
  }

  Future<int> atualizarQuantidade(
    int id,
    int novaQuantidade,
  ) async {
    try {
      final db = await banco;

      print(
        'UPDATE QUANTIDADE - ID: $id - NOVA QUANTIDADE: $novaQuantidade',
      );

      return await db.update(
        'produtos',
        {
          'quantidade': novaQuantidade,
        },
        where: 'id = ?',
        whereArgs: [id],
      );
    } catch (e, stack) {
      print('ERRO AO ATUALIZAR QUANTIDADE: $e');
      print(stack);
      return 0;
    }
  }

  Future<int> excluirProduto(int id) async {
    try {
      final db = await banco;

      print('DELETE PRODUTO - ID: $id');

      final resultado = await db.delete(
        'produtos',
        where: 'id = ?',
        whereArgs: [id],
      );

      print('PRODUTO EXCLUIDO');

      return resultado;
    } catch (e, stack) {
      print('ERRO AO EXCLUIR PRODUTO: $e');
      print(stack);
      return 0;
    }
  }

  Future<void> mostrarProdutosNoTerminal() async {
    try {
      final produtos = await listarProdutos();

      print('========================================');
      print('ESTOQUE ATUAL');

      if (produtos.isEmpty) {
        print('NENHUM PRODUTO CADASTRADO');
      }

      for (final produto in produtos) {
        print(
          'ID: ${produto['id']} | '
          'Nome: ${produto['nome']} | '
          'Categoria: ${produto['categoria']} | '
          'Quantidade: ${produto['quantidade']} | '
          'Preço: R\$ ${produto['preco']}',
        );
      }

      print('========================================');
    } catch (e) {
      print('ERRO AO MOSTRAR PRODUTOS: $e');
    }
  }
}