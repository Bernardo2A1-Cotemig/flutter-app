import 'package:sqflite/sqflite.dart';

class UsuarioService {
  UsuarioService._();

  static final UsuarioService instance = UsuarioService._();

  Database? _database;

  Future<Database> get banco async {
    if (_database != null) {
      return _database!;
    }

    try {
      print('========================================');
      print('ABRINDO SQLITE...');

      _database = await openDatabase(
        'estoque.db',
        version: 1,
        singleInstance: true,
        onCreate: (db, version) async {
          print('CRIANDO TABELA USUARIOS...');

          await db.execute('''
            CREATE TABLE usuarios (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              nome TEXT NOT NULL,
              email TEXT NOT NULL UNIQUE,
              senha TEXT NOT NULL
            )
          ''');

          await db.execute('''
            CREATE TABLE produtos (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              nome TEXT NOT NULL,
              categoria TEXT NOT NULL,
              quantidade INTEGER NOT NULL,
              preco REAL NOT NULL
            )
          ''');

          print('TABELAS CRIADAS COM SUCESSO!');
        },
      );

      print('SQLITE ABERTO COM SUCESSO!');
      print('========================================');

      return _database!;
    } catch (e, stack) {
      print('========================================');
      print('ERRO AO ABRIR SQLITE: $e');
      print(stack);
      print('========================================');

      rethrow;
    }
  }

  Future<int> inserirUsuario({
    required String nome,
    required String email,
    required String senha,
  }) async {
    try {
      final db = await banco;

      print('INSERT USUARIO: $email');

      final id = await db.insert(
        'usuarios',
        {
          'nome': nome,
          'email': email,
          'senha': senha,
        },
        conflictAlgorithm: ConflictAlgorithm.abort,
      );

      print('USUARIO INSERIDO COM ID: $id');

      return id;
    } catch (e) {
      print('ERRO AO INSERIR USUARIO: $e');
      return -1;
    }
  }

  Future<Map<String, dynamic>?> buscarLogin(
    String email,
    String senha,
  ) async {
    try {
      final db = await banco;

      print('SELECT LOGIN: $email');

      final resultado = await db.query(
        'usuarios',
        where: 'email = ? AND senha = ?',
        whereArgs: [email, senha],
        limit: 1,
      );

      if (resultado.isEmpty) {
        print('LOGIN NAO ENCONTRADO');
        return null;
      }

      print('LOGIN ENCONTRADO: ${resultado.first}');

      return resultado.first;
    } catch (e, stack) {
      print('ERRO NO SELECT LOGIN: $e');
      print(stack);

      rethrow;
    }
  }

  Future<bool> emailExiste(String email) async {
    try {
      final db = await banco;

      final resultado = await db.query(
        'usuarios',
        where: 'email = ?',
        whereArgs: [email],
        limit: 1,
      );

      return resultado.isNotEmpty;
    } catch (e) {
      print('ERRO AO VERIFICAR EMAIL: $e');
      rethrow;
    }
  }
}