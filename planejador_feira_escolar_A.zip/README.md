# Planejador de Feira Escolar (Versão A)

Aplicativo Flutter desenvolvido para o desafio **"Planejador de evento
escolar"**. Permite configurar uma atividade da feira (oficina, palestra,
exposição, competição ou apresentação cultural), acompanhar em tempo real
um painel de pré-visualização e, na sequência, visualizar uma tela de
resumo com a análise completa da atividade (situação, barra de preparação
e tabela de informações).

Este pacote contém **apenas o código-fonte Flutter** (pasta `lib/` e
`pubspec.yaml`), sem as pastas de plataforma (`android/`, `ios/`, `web/`
etc.), pois elas são geradas automaticamente pelo próprio Flutter e não
fazem parte da lógica do projeto.

## Como executar

1. Tenha o Flutter SDK instalado (`flutter --version` para confirmar).
2. Crie um novo projeto Flutter em uma pasta separada:
   ```bash
   flutter create planejador_feira_escolar
   ```
3. Copie o conteúdo deste pacote (`lib/`, `pubspec.yaml`,
   `analysis_options.yaml`) para dentro da pasta criada no passo 2,
   substituindo os arquivos gerados automaticamente.
4. Instale as dependências:
   ```bash
   flutter pub get
   ```
5. Execute o aplicativo:
   ```bash
   flutter run
   ```

O projeto usa apenas pacotes padrão do Flutter (`cupertino_icons` e
`flutter_lints`), não é necessária nenhuma configuração extra, chave de
API ou permissão especial.

## Estrutura do projeto

```
lib/
  main.dart                     -> tema do app e ponto de entrada
  models/activity_model.dart    -> classe ActivityConfig com todas as regras
  screens/config_screen.dart    -> Tela 1: Configuração da atividade
  screens/summary_screen.dart   -> Tela 2: Resumo e análise
  widgets/section_card.dart     -> cartão padrão para cada seção
  widgets/preview_panel.dart    -> painel de pré-visualização animado
```

Toda a lógica de análise (classificação, duração formatada, alertas,
validação, contagem de etapas) fica concentrada em `ActivityConfig`
(`lib/models/activity_model.dart`), o que facilita a leitura e a
manutenção das regras descritas no enunciado.

## Requisitos atendidos e decisões de implementação

- **Campos iniciais**: nome da atividade, responsável e local são
  `TextField`; a quantidade máxima de participantes é definida
  exclusivamente pelo controle visual (slider) da seção "Regra de
  capacidade", já que o enunciado pede uma forma visual para alterar
  esse mesmo valor — evitando ter dois controles diferentes para a
  mesma informação.
- **Tipo de atividade**: `Wrap` com `ChoiceChip`, uma única seleção,
  que quebra de linha automaticamente sem causar overflow. Ao trocar o
  tipo, cor, ícone, borda e mensagem do painel de pré-visualização mudam.
- **Duração**: selecionada por `Slider` (15–180 min, sem campo de
  texto), convertida para o formato "X hora(s) e Y minutos".
- **Recursos**: seção recolhível (`ExpansionTile`) com um `SwitchListTile`
  por recurso (projetor, computadores, sistema de som, acesso à
  internet, mesas adicionais).
- **Capacidade e classificação**: `Slider` de 5 a 100 participantes;
  classificação (pequena/média/grande) recalculada automaticamente.
- **Painel de pré-visualização**: atualizado em tempo real, com
  `AnimatedContainer`/`AnimatedSwitcher` reagindo a mudanças de tipo,
  capacidade e classificação (cor, borda, sombra e ícone animados).
- **Regras especiais** (1 a 5) implementadas exatamente como descritas:
  1. Palestra ativa o projetor automaticamente (pode ser desativado depois).
  2. Aviso "Verifique se o laboratório possui computadores suficientes."
     quando computadores estiverem ativos e participantes > 30.
  3. Sistema de som marcado como "Recomendado" (sem ativação automática)
     quando o tipo for Apresentação cultural.
  4. Aviso de duração mínima (60 min) quando o tipo for Competição.
  5. Botão de finalizar bloqueia a navegação e informa, por mensagem,
     quais campos obrigatórios (nome, responsável, local, capacidade
     válida) ainda faltam.
- **Indicador de preparação**: contagem de 7 etapas (nome, responsável,
  local, tipo, duração alterada, capacidade alterada, pelo menos um
  recurso analisado), exibida no botão flutuante ("Analisar - X de 7").
- **Menu lateral**: Nova atividade, Atividade atual, Limpar formulário
  e Sobre o evento. "Nova atividade" e "Limpar formulário" restauram
  todos os campos ao estado inicial (o enunciado detalha esse
  comportamento apenas para "Limpar formulário"; foi aplicado também a
  "Nova atividade" por ser a interpretação mais coerente com o nome da
  opção), fecham o menu e mostram uma mensagem de confirmação diferente
  para cada uma. "Atividade atual" mostra um resumo rápido em um
  diálogo; "Sobre o evento" mostra o contexto do desafio.
- **Tela de resumo**: situação geral ("Pronta para cadastro" ou "Requer
  atenção", com a lista de alertas correspondente), barra de preparação
  calculada a partir das 7 etapas (nunca digitada manualmente) e uma
  tabela responsiva (`Table` com `IntrinsicColumnWidth` +
  `FlexColumnWidth`, texto com quebra automática) que não gera overflow
  horizontal em telas pequenas.

## Observação sobre a dupla de projetos

Este projeto é a **Versão A** de dois aplicativos entregues para o
mesmo trabalho (veja também a Versão B). Ambos implementam exatamente
as mesmas regras e funcionalidades do enunciado, mas com aparência,
paleta de cores e escolhas de widgets diferentes (ex.: chips x botões
customizados, `ExpansionTile` x `ExpansionPanelList`, slider x
slider+stepper), para que os dois trabalhos sejam visualmente distintos.
