import 'package:flutter/material.dart';
import 'screens/config_screen.dart';

void main() {
  runApp(const FeiraEscolarApp());
}

class FeiraEscolarApp extends StatelessWidget {
  const FeiraEscolarApp({super.key});

  @override
  Widget build(BuildContext context) {
    final baseColor = const Color(0xFF00897B);
    return MaterialApp(
      title: 'Planejador de Feira Escolar',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(
          seedColor: baseColor,
          brightness: Brightness.light,
        ),
        scaffoldBackgroundColor: const Color(0xFFF4F6F5),
        appBarTheme: const AppBarTheme(
          centerTitle: true,
          elevation: 0,
        ),
        cardTheme: CardThemeData(
          elevation: 2,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          margin: const EdgeInsets.symmetric(vertical: 8),
        ),
        inputDecorationTheme: InputDecorationTheme(
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(12)),
          filled: true,
          fillColor: Colors.white,
        ),
      ),
      home: const ConfigScreen(),
    );
  }
}
