import 'package:flutter/material.dart';

/// Tipos de atividade que podem ser cadastrados na feira escolar.
enum ActivityType {
  oficina,
  palestra,
  exposicao,
  competicao,
  apresentacaoCultural,
}

/// Informacoes visuais e textuais associadas a cada tipo de atividade.
extension ActivityTypeInfo on ActivityType {
  String get label {
    switch (this) {
      case ActivityType.oficina:
        return 'Oficina';
      case ActivityType.palestra:
        return 'Palestra';
      case ActivityType.exposicao:
        return 'Exposição';
      case ActivityType.competicao:
        return 'Competição';
      case ActivityType.apresentacaoCultural:
        return 'Apresentação cultural';
    }
  }

  IconData get icon {
    switch (this) {
      case ActivityType.oficina:
        return Icons.handyman_outlined;
      case ActivityType.palestra:
        return Icons.record_voice_over_outlined;
      case ActivityType.exposicao:
        return Icons.photo_library_outlined;
      case ActivityType.competicao:
        return Icons.emoji_events_outlined;
      case ActivityType.apresentacaoCultural:
        return Icons.theater_comedy_outlined;
    }
  }

  Color get color {
    switch (this) {
      case ActivityType.oficina:
        return const Color(0xFF00897B); // teal
      case ActivityType.palestra:
        return const Color(0xFF3949AB); // indigo
      case ActivityType.exposicao:
        return const Color(0xFFEF6C00); // orange
      case ActivityType.competicao:
        return const Color(0xFFC62828); // red
      case ActivityType.apresentacaoCultural:
        return const Color(0xFF6A1B9A); // purple
    }
  }

  /// Cada tipo tem um formato de borda diferente no painel de pre-visualizacao.
  double get previewBorderRadius {
    switch (this) {
      case ActivityType.oficina:
        return 12;
      case ActivityType.palestra:
        return 4;
      case ActivityType.exposicao:
        return 24;
      case ActivityType.competicao:
        return 0;
      case ActivityType.apresentacaoCultural:
        return 32;
    }
  }

  String get previewMessage {
    switch (this) {
      case ActivityType.oficina:
        return 'Atividade prática com participação direta dos alunos.';
      case ActivityType.palestra:
        return 'Apresentação expositiva conduzida por um palestrante.';
      case ActivityType.exposicao:
        return 'Exibição de trabalhos, projetos ou produções.';
      case ActivityType.competicao:
        return 'Disputa com regras, tempo definido e resultado final.';
      case ActivityType.apresentacaoCultural:
        return 'Apresentação artística ou cultural ao público.';
    }
  }
}

/// Chaves fixas utilizadas para os recursos configuraveis da atividade.
class ResourceKeys {
  static const projetor = 'Projetor';
  static const computadores = 'Computadores';
  static const som = 'Sistema de som';
  static const internet = 'Acesso à internet';
  static const mesas = 'Mesas adicionais';

  static const List<String> all = [projetor, computadores, som, internet, mesas];
}

/// Representa toda a configuracao de uma atividade da feira escolar, alem
/// de concentrar as regras de analise usadas nas duas telas do aplicativo.
class ActivityConfig {
  final String name;
  final String responsible;
  final String location;
  final ActivityType? type;
  final int durationMinutes;
  final int capacity;
  final Map<String, bool> resources;
  final Set<String> touchedResources;
  final bool durationTouched;
  final bool capacityTouched;

  static const int totalSteps = 7;
  static const int minDuration = 15;
  static const int maxDuration = 180;
  static const int minCapacity = 5;
  static const int maxCapacity = 100;
  static const int competitionMinDuration = 60;
  static const int computersWarningThreshold = 30;

  ActivityConfig({
    this.name = '',
    this.responsible = '',
    this.location = '',
    this.type,
    this.durationMinutes = minDuration,
    this.capacity = minCapacity,
    Map<String, bool>? resources,
    Set<String>? touchedResources,
    this.durationTouched = false,
    this.capacityTouched = false,
  })  : resources = resources ?? {for (final r in ResourceKeys.all) r: false},
        touchedResources = touchedResources ?? <String>{};

  ActivityConfig copyWith({
    String? name,
    String? responsible,
    String? location,
    ActivityType? type,
    bool clearType = false,
    int? durationMinutes,
    int? capacity,
    Map<String, bool>? resources,
    Set<String>? touchedResources,
    bool? durationTouched,
    bool? capacityTouched,
  }) {
    return ActivityConfig(
      name: name ?? this.name,
      responsible: responsible ?? this.responsible,
      location: location ?? this.location,
      type: clearType ? null : (type ?? this.type),
      durationMinutes: durationMinutes ?? this.durationMinutes,
      capacity: capacity ?? this.capacity,
      resources: resources ?? Map<String, bool>.from(this.resources),
      touchedResources: touchedResources ?? Set<String>.from(this.touchedResources),
      durationTouched: durationTouched ?? this.durationTouched,
      capacityTouched: capacityTouched ?? this.capacityTouched,
    );
  }

  /// Classificacao da atividade de acordo com a quantidade de participantes.
  String get classification {
    if (capacity <= 20) return 'Atividade pequena';
    if (capacity <= 50) return 'Atividade média';
    return 'Atividade grande';
  }

  /// Converte a duracao em minutos para um texto legivel em horas e minutos.
  String get formattedDuration {
    final hours = durationMinutes ~/ 60;
    final minutes = durationMinutes % 60;
    if (hours == 0) return '$minutes minutos';
    final hourText = hours == 1 ? '1 hora' : '$hours horas';
    if (minutes == 0) return hourText;
    return '$hourText e $minutes minutos';
  }

  int get activeResourcesCount => resources.values.where((v) => v).length;

  /// Quantidade de etapas (de 7) ja concluidas pelo usuario.
  int get stepsCompleted {
    var steps = 0;
    if (name.trim().isNotEmpty) steps++;
    if (responsible.trim().isNotEmpty) steps++;
    if (location.trim().isNotEmpty) steps++;
    if (type != null) steps++;
    if (durationTouched) steps++;
    if (capacityTouched) steps++;
    if (touchedResources.isNotEmpty) steps++;
    return steps;
  }

  double get progress => stepsCompleted / totalSteps;

  /// Lista de campos obrigatorios que ainda estao faltando (Regra 5).
  List<String> get missingRequiredFields {
    final missing = <String>[];
    if (name.trim().isEmpty) missing.add('nome da atividade');
    if (responsible.trim().isEmpty) missing.add('responsável');
    if (location.trim().isEmpty) missing.add('sala ou local');
    if (capacity < minCapacity || capacity > maxCapacity) {
      missing.add('quantidade de participantes');
    }
    return missing;
  }

  bool get canFinalize => missingRequiredFields.isEmpty;

  /// Regra 2: computadores ativados + mais de 30 participantes.
  bool get computersWarning =>
      (resources[ResourceKeys.computadores] ?? false) &&
      capacity > computersWarningThreshold;

  /// Regra 3: som recomendado (nao ativado automaticamente).
  bool get soundRecommended => type == ActivityType.apresentacaoCultural;

  /// Regra 4: competicao com duracao menor que o minimo permitido.
  bool get competitionTooShort =>
      type == ActivityType.competicao && durationMinutes < competitionMinDuration;

  /// Alertas apresentados na tela de resumo (situacao "Requer atenção").
  List<String> get alerts {
    final list = <String>[];
    if (competitionTooShort) {
      list.add('Competição com duração abaixo do mínimo de $competitionMinDuration minutos.');
    }
    if (computersWarning) {
      list.add('Muitos participantes utilizando computadores (mais de $computersWarningThreshold).');
    }
    if (type == ActivityType.apresentacaoCultural &&
        !(resources[ResourceKeys.som] ?? false)) {
      list.add('Apresentação cultural sem sistema de som.');
    }
    if (classification == 'Atividade grande' &&
        !(resources[ResourceKeys.mesas] ?? false)) {
      list.add('Atividade grande sem mesas adicionais.');
    }
    return list;
  }

  bool get isReady => alerts.isEmpty;
}
