import 'package:flutter/material.dart';
import '../models/activity_model.dart';
import '../widgets/section_card.dart';
import '../widgets/preview_panel.dart';
import 'summary_screen.dart';

class ConfigScreen extends StatefulWidget {
  const ConfigScreen({super.key});

  @override
  State<ConfigScreen> createState() => _ConfigScreenState();
}

class _ConfigScreenState extends State<ConfigScreen> {
  final _nameController = TextEditingController();
  final _responsibleController = TextEditingController();
  final _locationController = TextEditingController();

  ActivityConfig _config = ActivityConfig();
  bool _resourcesExpanded = false;

  @override
  void dispose() {
    _nameController.dispose();
    _responsibleController.dispose();
    _locationController.dispose();
    super.dispose();
  }

  void _updateConfig(ActivityConfig Function(ActivityConfig) update) {
    setState(() {
      _config = update(_config);
    });
  }

  void _selectType(ActivityType type) {
    _updateConfig((c) {
      var updated = c.copyWith(type: type);
      // Regra 1: Palestra ativa o projetor automaticamente.
      if (type == ActivityType.palestra) {
        final newResources = Map<String, bool>.from(updated.resources);
        newResources[ResourceKeys.projetor] = true;
        final newTouched = Set<String>.from(updated.touchedResources)
          ..add(ResourceKeys.projetor);
        updated = updated.copyWith(resources: newResources, touchedResources: newTouched);
      }
      return updated;
    });
  }

  void _toggleResource(String key, bool value) {
    _updateConfig((c) {
      final newResources = Map<String, bool>.from(c.resources)..[key] = value;
      final newTouched = Set<String>.from(c.touchedResources)..add(key);
      return c.copyWith(resources: newResources, touchedResources: newTouched);
    });
  }

  void _resetForm({required String message}) {
    setState(() {
      _nameController.clear();
      _responsibleController.clear();
      _locationController.clear();
      _config = ActivityConfig();
      _resourcesExpanded = false;
    });
    Navigator.of(context).maybePop();
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }

  void _showAbout() {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Sobre o evento'),
        content: const Text(
          'A escola realizará uma feira com apresentações, oficinas e '
          'exposições. Este aplicativo ajuda a configurar cada atividade, '
          'analisar as escolhas feitas e indicar se ela está pronta para '
          'ser cadastrada.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
  }

  void _showCurrentActivity() {
    final hasData = _config.name.trim().isNotEmpty || _config.type != null;
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Atividade atual'),
        content: Text(
          hasData
              ? 'Nome: ${_config.name.trim().isEmpty ? "(sem nome)" : _config.name}\n'
                  'Tipo: ${_config.type?.label ?? "(não selecionado)"}\n'
                  'Duração: ${_config.formattedDuration}\n'
                  'Participantes: ${_config.capacity}\n'
                  'Etapas concluídas: ${_config.stepsCompleted} de ${ActivityConfig.totalSteps}'
              : 'Nenhuma informação foi preenchida ainda.',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text('Fechar'),
          ),
        ],
      ),
    );
  }

  void _handleFinalize() {
    if (!_config.canFinalize) {
      final missing = _config.missingRequiredFields.join(', ');
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Informação(ões) faltando: $missing.')),
      );
      return;
    }
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => SummaryScreen(config: _config)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Configuração da atividade')),
      drawer: _buildDrawer(),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 90),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildInitialInfoSection(),
              _buildTypeSection(),
              _buildDurationSection(),
              _buildResourcesSection(),
              _buildCapacitySection(),
              const SizedBox(height: 4),
              Text(
                'Pré-visualização',
                style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold),
              ),
              PreviewPanel(config: _config),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _handleFinalize,
        icon: const Icon(Icons.fact_check_outlined),
        label: Text('Analisar - ${_config.stepsCompleted} de ${ActivityConfig.totalSteps}'),
      ),
    );
  }

  Widget _buildDrawer() {
    return Drawer(
      child: SafeArea(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Color(0xFF00897B)),
              child: Align(
                alignment: Alignment.bottomLeft,
                child: Text(
                  'Feira Escolar',
                  style: TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.add_circle_outline),
              title: const Text('Nova atividade'),
              onTap: () => _resetForm(message: 'Nova atividade iniciada.'),
            ),
            ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('Atividade atual'),
              onTap: () {
                Navigator.of(context).pop();
                _showCurrentActivity();
              },
            ),
            ListTile(
              leading: const Icon(Icons.cleaning_services_outlined),
              title: const Text('Limpar formulário'),
              onTap: () => _resetForm(message: 'Formulário limpo com sucesso.'),
            ),
            ListTile(
              leading: const Icon(Icons.help_outline),
              title: const Text('Sobre o evento'),
              onTap: () {
                Navigator.of(context).pop();
                _showAbout();
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInitialInfoSection() {
    return SectionCard(
      title: 'Informações iniciais',
      icon: Icons.edit_note_outlined,
      child: Column(
        children: [
          TextField(
            controller: _nameController,
            decoration: const InputDecoration(labelText: 'Nome da atividade'),
            onChanged: (v) => _updateConfig((c) => c.copyWith(name: v)),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _responsibleController,
            decoration: const InputDecoration(labelText: 'Nome do responsável'),
            onChanged: (v) => _updateConfig((c) => c.copyWith(responsible: v)),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _locationController,
            decoration: const InputDecoration(labelText: 'Sala ou local'),
            onChanged: (v) => _updateConfig((c) => c.copyWith(location: v)),
          ),
        ],
      ),
    );
  }

  Widget _buildTypeSection() {
    return SectionCard(
      title: 'Tipo de atividade',
      icon: Icons.category_outlined,
      child: Wrap(
        spacing: 8,
        runSpacing: 8,
        children: ActivityType.values.map((type) {
          final selected = _config.type == type;
          return ChoiceChip(
            label: Text(type.label),
            avatar: Icon(type.icon, size: 18, color: selected ? Colors.white : type.color),
            selected: selected,
            selectedColor: type.color,
            labelStyle: TextStyle(color: selected ? Colors.white : Colors.black87),
            onSelected: (_) => _selectType(type),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildDurationSection() {
    final tooShort = _config.competitionTooShort;
    return SectionCard(
      title: 'Duração da atividade',
      icon: Icons.timer_outlined,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            _config.formattedDuration,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          Slider(
            min: ActivityConfig.minDuration.toDouble(),
            max: ActivityConfig.maxDuration.toDouble(),
            divisions: (ActivityConfig.maxDuration - ActivityConfig.minDuration) ~/ 5,
            value: _config.durationMinutes.toDouble(),
            label: _config.formattedDuration,
            onChanged: (v) => _updateConfig(
              (c) => c.copyWith(durationMinutes: v.round(), durationTouched: true),
            ),
          ),
          if (tooShort)
            Padding(
              padding: const EdgeInsets.only(top: 4),
              child: Row(
                children: [
                  Icon(Icons.warning_amber_rounded, color: Colors.orange.shade800, size: 18),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      'Atenção: competições devem ter duração mínima de '
                      '${ActivityConfig.competitionMinDuration} minutos.',
                      style: TextStyle(color: Colors.orange.shade800),
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildResourcesSection() {
    return Card(
      child: ExpansionTile(
        initiallyExpanded: _resourcesExpanded,
        onExpansionChanged: (v) => setState(() => _resourcesExpanded = v),
        leading: const Icon(Icons.build_circle_outlined),
        title: const Text('Recursos necessários', style: TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text('${_config.activeResourcesCount} recurso(s) ativado(s)'),
        children: [
          for (final key in ResourceKeys.all) _buildResourceRow(key),
        ],
      ),
    );
  }

  Widget _buildResourceRow(String key) {
    final isComputers = key == ResourceKeys.computadores;
    final isSound = key == ResourceKeys.som;
    final showComputersWarning = isComputers && _config.computersWarning;
    final showSoundRecommended = isSound && _config.soundRecommended;

    return Column(
      children: [
        SwitchListTile(
          title: Text(key),
          value: _config.resources[key] ?? false,
          secondary: showSoundRecommended
              ? const Chip(label: Text('Recomendado'), visualDensity: VisualDensity.compact)
              : null,
          onChanged: (v) => _toggleResource(key, v),
        ),
        if (showComputersWarning)
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 8),
            child: Row(
              children: [
                Icon(Icons.warning_amber_rounded, color: Colors.orange.shade800, size: 18),
                const SizedBox(width: 6),
                const Expanded(
                  child: Text('Verifique se o laboratório possui computadores suficientes.'),
                ),
              ],
            ),
          ),
      ],
    );
  }

  Widget _buildCapacitySection() {
    return SectionCard(
      title: 'Quantidade máxima de participantes',
      icon: Icons.groups_outlined,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Text(
            '${_config.capacity} participantes',
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          Slider(
            min: ActivityConfig.minCapacity.toDouble(),
            max: ActivityConfig.maxCapacity.toDouble(),
            divisions: ActivityConfig.maxCapacity - ActivityConfig.minCapacity,
            value: _config.capacity.toDouble(),
            label: '${_config.capacity}',
            onChanged: (v) => _updateConfig(
              (c) => c.copyWith(capacity: v.round(), capacityTouched: true),
            ),
          ),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
            decoration: BoxDecoration(
              color: Colors.teal.withOpacity(0.08),
              borderRadius: BorderRadius.circular(10),
            ),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                const Icon(Icons.bar_chart_outlined, size: 18, color: Colors.teal),
                const SizedBox(width: 8),
                Text(
                  _config.classification,
                  style: const TextStyle(fontWeight: FontWeight.bold, color: Colors.teal),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
