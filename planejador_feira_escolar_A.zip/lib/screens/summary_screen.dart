import 'package:flutter/material.dart';
import '../models/activity_model.dart';

class SummaryScreen extends StatelessWidget {
  final ActivityConfig config;

  const SummaryScreen({super.key, required this.config});

  @override
  Widget build(BuildContext context) {
    final isReady = config.isReady;
    final percent = (config.progress * 100).round();

    return Scaffold(
      appBar: AppBar(title: const Text('Resumo e análise')),
      body: SafeArea(
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _buildSituationCard(isReady),
              const SizedBox(height: 16),
              _buildProgressSection(percent),
              const SizedBox(height: 16),
              _buildInfoTable(context, isReady),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildSituationCard(bool isReady) {
    final color = isReady ? const Color(0xFF2E7D32) : const Color(0xFFEF6C00);
    final icon = isReady ? Icons.check_circle_outline : Icons.warning_amber_rounded;
    final title = isReady ? 'Pronta para cadastro' : 'Requer atenção';

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: color, width: 2),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(icon, color: color, size: 30),
              const SizedBox(width: 10),
              Expanded(
                child: Text(
                  title,
                  style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: color),
                ),
              ),
            ],
          ),
          if (config.alerts.isNotEmpty) ...[
            const SizedBox(height: 12),
            ...config.alerts.map(
              (a) => Padding(
                padding: const EdgeInsets.only(bottom: 6),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.circle, size: 8, color: color),
                    const SizedBox(width: 8),
                    Expanded(child: Text(a)),
                  ],
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildProgressSection(int percent) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Barra de preparação', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            ClipRRect(
              borderRadius: BorderRadius.circular(8),
              child: LinearProgressIndicator(
                value: config.progress,
                minHeight: 14,
                backgroundColor: Colors.grey.shade300,
                color: const Color(0xFF00897B),
              ),
            ),
            const SizedBox(height: 6),
            Text(
              '${config.stepsCompleted} de ${ActivityConfig.totalSteps} etapas concluídas ($percent%)',
              style: TextStyle(color: Colors.grey.shade700),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoTable(BuildContext context, bool isReady) {
    final rows = <List<String>>[
      ['Atividade', config.name],
      ['Responsável', config.responsible],
      ['Tipo', config.type?.label ?? '-'],
      ['Duração', config.formattedDuration],
      ['Capacidade', '${config.capacity} participantes'],
      ['Classificação', config.classification],
      ['Recursos ativos', '${config.activeResourcesCount}'],
      ['Situação', isReady ? 'Pronta para cadastro' : 'Requer atenção'],
    ];

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Informações da atividade', style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 10),
            Table(
              border: TableBorder.all(color: Colors.grey.shade300, borderRadius: BorderRadius.circular(6)),
              columnWidths: const {
                0: IntrinsicColumnWidth(),
                1: FlexColumnWidth(),
              },
              children: [
                TableRow(
                  decoration: BoxDecoration(color: Colors.teal.withOpacity(0.12)),
                  children: const [
                    _TableHeaderCell('Informação'),
                    _TableHeaderCell('Valor'),
                  ],
                ),
                for (final row in rows)
                  TableRow(
                    children: [
                      _TableCell(row[0], bold: true),
                      _TableCell(row[1]),
                    ],
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _TableHeaderCell extends StatelessWidget {
  final String text;
  const _TableHeaderCell(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      child: Text(text, style: const TextStyle(fontWeight: FontWeight.bold)),
    );
  }
}

class _TableCell extends StatelessWidget {
  final String text;
  final bool bold;
  const _TableCell(this.text, {this.bold = false});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 8),
      child: Text(
        text,
        softWrap: true,
        style: TextStyle(fontWeight: bold ? FontWeight.w600 : FontWeight.normal),
      ),
    );
  }
}
