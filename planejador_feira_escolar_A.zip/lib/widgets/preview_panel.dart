import 'package:flutter/material.dart';
import '../models/activity_model.dart';

/// Painel que resume, em tempo real, a configuracao atual da atividade.
/// Utiliza AnimatedContainer para reagir visualmente a mudancas importantes
/// (tipo, capacidade/classificacao).
class PreviewPanel extends StatelessWidget {
  final ActivityConfig config;

  const PreviewPanel({super.key, required this.config});

  @override
  Widget build(BuildContext context) {
    final type = config.type;
    final color = type?.color ?? Colors.grey;
    final borderRadius = type?.previewBorderRadius ?? 16;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 350),
      curve: Curves.easeInOut,
      margin: EdgeInsets.symmetric(
        vertical: 8,
        horizontal: config.classification == 'Atividade grande' ? 0 : 6,
      ),
      padding: const EdgeInsets.all(18),
      decoration: BoxDecoration(
        color: color.withOpacity(0.10),
        borderRadius: BorderRadius.circular(borderRadius),
        border: Border.all(color: color, width: 2),
        boxShadow: [
          BoxShadow(
            color: color.withOpacity(0.25),
            blurRadius: config.classification == 'Atividade grande' ? 14 : 6,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: Icon(
                  type?.icon ?? Icons.event_note_outlined,
                  key: ValueKey(type),
                  color: color,
                  size: 32,
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: Text(
                  config.name.trim().isEmpty ? 'Nova atividade' : config.name,
                  style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Text(
            type?.previewMessage ?? 'Selecione um tipo de atividade para continuar.',
            style: TextStyle(color: Colors.grey.shade800),
          ),
          const Divider(height: 20),
          Wrap(
            spacing: 16,
            runSpacing: 8,
            children: [
              _InfoChip(icon: Icons.category_outlined, label: type?.label ?? 'Sem tipo'),
              _InfoChip(icon: Icons.timer_outlined, label: config.formattedDuration),
              _InfoChip(
                icon: Icons.groups_outlined,
                label: '${config.capacity} participantes',
              ),
              _InfoChip(icon: Icons.bar_chart_outlined, label: config.classification),
              _InfoChip(
                icon: Icons.check_circle_outline,
                label: '${config.activeResourcesCount} recurso(s) ativo(s)',
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _InfoChip extends StatelessWidget {
  final IconData icon;
  final String label;

  const _InfoChip({required this.icon, required this.label});

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 16, color: Colors.grey.shade700),
        const SizedBox(width: 4),
        Text(label, style: TextStyle(color: Colors.grey.shade800, fontSize: 13)),
      ],
    );
  }
}
